<?php

include 'connection.php';
$id = $_REQUEST['id'];
$select_query = "select e.id, e.firstName, e.lastName, e.email, e.hobbies, e.bio, s.skills from employee_records e left join employee_skills s on e.id = s.emp_id where e.id = '$id'";
$result = mysqli_query($con, $select_query);
$row = mysqli_fetch_array($result);
$hobbies = $row['hobbies'];
$update_hobby = explode(",", $hobbies);
// print_r($update_hobby);
if(!$result)
{
	echo ("Error while fetching records from table"."&nbsp;".mysqli_connect_error());
}


if(isset($_POST['submit']))
{
	$firstName = validation(mysqli_real_escape_string($con, $_POST['firstName']));
	$lastName = validation(mysqli_real_escape_string($con, $_POST['lastName']));
	$email = validation(mysqli_real_escape_string($con, $_POST['email']));
	$hobby = implode(',', $_POST['hobby']);
	$bio = validation(mysqli_real_escape_string($con, $_POST['bio']));
	$skills = validation(mysqli_real_escape_string($con, $_POST['skills']));
	$update_query = "update employee_records set firstName = '$firstName', lastName = '$lastName', email = '$email', hobbies = '$hobby', bio = '$bio' where id = '$id'";
	$query_execute = mysqli_query($con, $update_query);
	if(!$query_execute)
	{
		echo ("Error while updating records in employee_records table"."&nbsp;".mysqli_connect_errno());
	}
	else
	{
		$update_skills = "update employee_skills set skills = '$skills' where emp_id = $id";
		$skills_execute = mysqli_query($con, $update_skills);
		if(!$skills_execute)
		{
			echo ("Error while updating reference table"."&nbsp;".mysqli_connect_errno());
		}
		else
		{
			header('location: employee_records.php');
		}
	}
}

	function validation($data)
	{
		$data = trim($data);
	  	$data = stripslashes($data);
	  	$data = htmlspecialchars($data);
	  	return $data;    
	}

?>
<!DOCTYPE html>
<html>
	<body>
		<h2>UPDATE EMPLOYEE RECORDS</h2>
		<form method="POST" action="">
			<div>
				<label for="firstName">First Name:</label>
				<input type="text" name="firstName" value="<?php echo $row['firstName'];?>" placeholder="Enter first name" required />
			</div>
			<div>
				<label for="lastName">Last Name:</label>
				<input type="text" name="lastName" value="<?php echo $row['lastName'];?>" placeholder="Enter last name" required />
			</div>
			<div>
				<label for="email">Email:</label>
				<input type="email" name="email" value="<?php echo $row['email'];?>" placeholder="Enter email address" required />
			</div>
			<div>
				<label for="hobbies">Hobbies</label>
				<input type="checkbox" name="hobby[ ]" <?php if(in_array("Reading Books", $update_hobby)) echo "checked";?> value="Reading Books">Reading Books
				<input type="checkbox" name="hobby[ ]" <?php if(in_array("Surfing Internet", $update_hobby)) echo "checked";?> value="Surfing Internet">Surfing Internet
				<input type="checkbox" name="hobby[ ]" <?php if(in_array("Exploring New Things", $update_hobby)) echo "checked";?> value="Exploring New Things">Exploring New Things
				<input type="checkbox" name="hobby[ ]" <?php if(in_array("Traveling", $update_hobby)) echo "checked";?> value="Traveling">Traveling
			</div>
			<div>
				<label for="bio">Bio:</label>
				<textarea name="bio" rows="5"><?php echo $row['bio'];?></textarea>
			</div>
			<div>
				<label for="skills">Skills:</label>
				<input type="text" name="skills" value="<?php echo $row['skills']; ?>" placeholder="Enter your skill" required />
			</div>
			<div>
				<input type="submit" name="submit" value="Update"/>
			</div>
		</form>
	</body>
</html>