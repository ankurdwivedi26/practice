<?php

include 'connection.php';
$id = $_REQUEST['id'];
$delete_query = "delete from employee_records where id = '$id'";
$result = mysqli_query($con, $delete_query);
if(!$result)
{
	echo ("Error while deleting records from table"."&nbsp;".mysqli_connect_errno());
}
else
{
	header('location:employee_records.php');
}

?>