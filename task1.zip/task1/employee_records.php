<?php 

// $con = mysqli_connect('localhost', 'root', 'Centire@123', 'employee');
include 'connection.php';

?>

<!DOCTYPE html>
<html>
	<body>
		<h2>VIEW RECORDS</h2>
		<table border="1">
			<thead>
				<th>Id</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Hobbies</th>
				<th>Bio</th>
				<th>Skills</th>
				<th>Edit</th>
				<th>Delete</th>
			</thead>
			<?php
				$select_query = "select e.id, e.firstName, e.lastName, e.email, e.hobbies, e.bio, s.skills  from employee_records e left join employee_skills s on e.id = s.emp_id";
				$result = mysqli_query($con, $select_query);
				while ($row = mysqli_fetch_array($result))
				{
			?>
			<tr>
				<td><?php echo $row['id']; ?></td>
				<td><?php echo $row['firstName']; ?></td>
				<td><?php echo $row['lastName']; ?></td>
				<td><?php echo $row['email']; ?></td>
				<td><?php echo $row['hobbies']; ?></td>
				<td><?php echo $row['bio']; ?></td>
				<td><?php echo $row['skills']; ?></td>
				<td><a href="update_employee.php?id=<?php echo $row['id'];?>">Edit</a></td>
				<td><a href="delete_employee.php?id=<?php echo $row['id'];?>" onclick="return confirm('Are you sure?')">Delete</a></td>
			</tr>
			<?php 
				}
			?>
		</table>
	</body>
</html>