<?php

// $con = mysqli_connect('localhost', 'root', 'Centire@123', 'employee');
include 'connection.php';
if(isset($_POST['submit']))
{

	$firstName = validation(mysqli_real_escape_string($con, $_POST['firstName']));
	$lastName = validation(mysqli_real_escape_string($con, $_POST['lastName']));
	$email = validation(mysqli_real_escape_string($con, $_POST['email']));
	$hobby = implode(',', $_POST['hobby']);
	$bio = validation(mysqli_real_escape_string($con, $_POST['bio']));
	$skills = validation(mysqli_real_escape_string($con, $_POST['skills']));
	$insert_query = "insert into employee_records(firstName, lastName, email, hobbies, bio) values('$firstName', '$lastName', '$email', '$hobby', '$bio')";
	$query_execute = mysqli_query($con, $insert_query);
	$last_id=mysqli_insert_id($con);
	if($query_execute==1)
	{
		$insert_skills = "insert into employee_skills(skills, emp_id) values('$skills', $last_id)";
		$execute = mysqli_query($con, $insert_skills);
		if(!$execute)
		{
			echo ("Record not inserted to employee_skills table"."".mysqli_connect_errno());
		}
		else
		{
			// echo "Data inserted successfully";
			header('location: employee_records.php');
		}
	}
	else
	{
		echo ("Error:"."&nbsp;".mysqli_connect_error());
	}
}

	function validation($data)
	{
		$data = trim($data);
	  	$data = stripslashes($data);
	  	$data = htmlspecialchars($data);
	  	return $data;    
	}	

?>

<!DOCTYPE html>
<html>
	<body>
		<h2>INSERT EMPLOYEE RECORDS</h2>
		<form method="POST" action="" enctype="multipart/form-data">
			<div>
				<label for="firstName">First Name:</label>
				<input type="text" name="firstName" placeholder="Enter first name" required/>
			</div>
			<div>
				<label for="lastName">Last Name:</label>
				<input type="text" name="lastName" placeholder="Enter last name" required/>
			</div>
			<div>
				<label for="email">Email:</label>
				<input type="email" name="email" placeholder="Enter email address" required/>
			</div>
			<div>
				<label for="hobbies">Hobbies</label>
				<input type="checkbox" name="hobby[ ]" value="Reading Books">Reading Books
				<input type="checkbox" name="hobby[ ]" value="Surfing Internet">Surfing Internet
				<input type="checkbox" name="hobby[ ]" value="Exploring New Things">Exploring New Things
				<input type="checkbox" name="hobby[ ]" value="Traveling">Traveling
			</div>
			<div>
				<label for="bio">Bio:</label>
				<textarea name="bio" rows="5"></textarea>
			</div>
			<div>
				<label for="skills">Skills:</label>
				<input type="text" name="skills" placeholder="Enter your skill" required /></textarea>
			</div>
			<div>
				<input type="submit" name="submit" value="Submit"/>
			</div>
		</form>
	</body>
</html>