<?php

	$host = 'localhost';
	$username = 'root';
	$password = 'Centire@123';
	$db = 'employee';
	$con = mysqli_connect($host, $username, $password, $db);
	if(!$con)
	{
		echo ("Error while establishing connection"."&nbsp;".mysqli_connect_errno());
	}
	// else{
	// 	echo "Connection OK";
	// }

?>